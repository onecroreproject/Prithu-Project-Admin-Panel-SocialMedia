import { useState } from "react";
import { FiMoreVertical } from "react-icons/fi";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { getRecentWithdrawalUsers } from "../../Services/SalesDashboardSecrvices/metricServices";

export default function RecentWithdrawalUsers() {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const navigate = useNavigate();

  const { data: users = [], isLoading, isError } = useQuery({
    queryKey: ["recentWithdrawals"],
    queryFn: () => getRecentWithdrawalUsers(5), // Limit to 5 for the card
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="relative rounded-2xl border border-gray-200 bg-linear-to-br from-indigo-50 via-white to-pink-50 px-5 pb-5 pt-5 shadow-md dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 sm:px-4 sm:pt-5 transition-all duration-500 hover:shadow-lg"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white/90">Recent Withdrawal Users</h3>
          <p className="mt-1 text-gray-500 text-theme-sm dark:text-gray-400">Latest users who withdrew recently</p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate("/settings/sales/withdrawals")}
            className="hidden sm:block px-3 py-1.5 text-xs font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors border border-rose-100"
          >
            View Detail
          </button>

          <div
            className="relative"
            onMouseEnter={() => setDropdownOpen(true)}
            onMouseLeave={() => setDropdownOpen(false)}
          >
            <button className="p-2 rounded-full hover:bg-indigo-100 dark:hover:bg-gray-700 transition">
              <FiMoreVertical className="text-gray-600 dark:text-gray-300" />
            </button>

            {dropdownOpen && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: -5 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl shadow-lg z-10"
              >
                <ul className="text-sm">
                  <li>
                    <button
                      onClick={() => navigate("/settings/sales/withdrawals")}
                      className="w-full text-left px-4 py-2 hover:bg-indigo-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200"
                    >
                      View Detail Table
                    </button>
                  </li>
                  <li>
                    <button
                      onClick={() => navigate("/social/profile")}
                      className="w-full text-left px-4 py-2 hover:bg-indigo-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200"
                    >
                      View All Users
                    </button>
                  </li>
                </ul>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Table with max 4 rows */}
      <div className="overflow-y-auto" style={{ maxHeight: 'calc(4 * 3rem)' }}>
        <table className="w-full text-sm text-left text-gray-700 dark:text-gray-200 table-fixed">
          <thead className="text-gray-600 uppercase text-xs border-b border-gray-200 dark:border-gray-700">
            <tr>
              <th className="py-2 px-2 w-1/2 truncate">User</th>
              <th className="py-2 px-2 w-1/4 truncate">Withdrawn</th>
              <th className="py-2 px-2 w-1/4 truncate text-right">Amount</th>
            </tr>
          </thead>
          <tbody>
            {isLoading && (
              <tr>
                <td colSpan={3} className="py-10 text-center text-gray-400 italic">
                  Loading withdrawals...
                </td>
              </tr>
            )}
            {isError && (
              <tr>
                <td colSpan={3} className="py-10 text-center text-rose-500 italic">
                  Failed to load data
                </td>
              </tr>
            )}
            {!isLoading && !isError && users.length === 0 && (
              <tr>
                <td colSpan={3} className="py-10 text-center text-gray-400 italic">
                  No data available
                </td>
              </tr>
            )}
            {!isLoading && !isError && users.map((user, idx) => (
              <tr
                key={user.id || idx}
                className="border-b border-gray-100 dark:border-gray-700 hover:bg-indigo-50/20 dark:hover:bg-white/5 transition-all text-xs"
              >
                <td className="py-2 px-2 flex items-center gap-2 truncate">
                  <img
                    src={user.avatar || "https://randomuser.me/api/portraits/lego/1.jpg"}
                    alt={user.userName}
                    className="w-7 h-7 rounded-full object-cover ring-1 ring-indigo-300 shrink-0"
                  />
                  <div className="truncate min-w-0">
                    <p className="font-semibold text-gray-800 dark:text-white truncate">{user.userName}</p>
                    <p className="text-[10px] text-gray-500 truncate">{user.email || "No email"}</p>
                  </div>
                </td>
                <td className="py-2 px-2 text-gray-500 dark:text-gray-400 truncate">
                  {user.processedAt ? new Date(user.processedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "-"}
                </td>
                <td className="py-2 px-2 text-rose-600 dark:text-rose-400 font-bold truncate text-right">
                  ₹{user.amount?.toLocaleString() || "0"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Glow */}
      <div className="absolute -top-5 -right-5 w-24 h-24 bg-indigo-300 rounded-full blur-2xl opacity-20 animate-pulse"></div>
      <div className="absolute bottom-0 left-0 w-20 h-20 bg-pink-300 rounded-full blur-2xl opacity-20 animate-pulse"></div>
    </motion.div>
  );
}
